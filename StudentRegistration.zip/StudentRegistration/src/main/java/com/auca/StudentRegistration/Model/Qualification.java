package com.auca.StudentRegistration.Model;

public enum Qualification {
    Master,
    Phd,
    Professor
}
